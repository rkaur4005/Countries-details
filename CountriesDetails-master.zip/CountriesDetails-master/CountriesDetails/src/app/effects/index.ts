import { DataEffects } from "./data.effects";

export const effects: any[] = [DataEffects];