export interface country{
    name:string;
}