export interface CountryDetails{
    name:string;
}