export interface region{
    name:string;
}